package hw2;

import java.util.List;

public interface VMInterface {

    List<EntryInterface> getEntries(int index);

    int size();

    EntryInterface getFinalEntry();

    void setFinalEntry(EntryInterface finalEntry);

    void addToken(List<EntryInterface> entries);

}
