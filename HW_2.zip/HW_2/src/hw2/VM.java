package hw2;

import java.util.ArrayList;
import java.util.List;

public class VM implements VMInterface {

    private final List<List<EntryInterface>> data;
    private EntryInterface finalEntry;

    public VM() {
        data = new ArrayList<>();
    }

    @Override
    public List<EntryInterface> getEntries(final int index) {
        return data.get(index);
    }

    @Override
    public int size() {
        return data.size();
    }

    @Override
    public EntryInterface getFinalEntry() {
        return finalEntry;
    }

    @Override
    public void setFinalEntry(final EntryInterface finalEntry) {
        this.finalEntry = finalEntry;
    }

    @Override
    public void addToken(final List<EntryInterface> entries) {
        data.add(entries);
    }

}
