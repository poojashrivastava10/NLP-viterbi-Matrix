package hw2;



import java.util.Arrays;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

public class Main {

    public static final String VERB = "Verb";
    public static final String ADVERB = "Adverb";
    public static final String NOUN = "Noun";
    public static final String START = "Start";
    public static final String STOP = "Stop";

    public static void main(String[] args) {
        final LanguageModelInterface model = new LanguageModel();
        // Setting up the transitions.
        Transitions(model);
        // Setting up the emissions.
        Emissions(model);
        // Creating input phrase:
        final String[] phrase = createPhrase();
        // Create a Viterbi matrix out of the phrase
        final VMInterface matrix = createVM(model, phrase);
        // Print the matrix.
        printMatrix(model, phrase, matrix);
        // Print the tagging.
        printTagging(matrix);
    }

    private static void printTagging(final VMInterface matrix) {
        final StringBuilder builder = new StringBuilder();
        EntryInterface entry = matrix.getFinalEntry().previous();
        while (entry != null) {
            builder.insert(0, "(" + entry.token() + "," + entry.POS() + ")  ");
            entry = entry.previous();
        }
        System.out.println("The final result:");
        System.out.println(builder.toString().trim());
    }

    private static void printMatrix(final LanguageModelInterface model, final String[] phrase, final VMInterface matrix) {
        final String headline = "Viterbi Matrix for the line: " + Arrays.toString(phrase);
        System.out.println(headline);
        System.out.println(new String(new char[headline.length()+23]).replaceAll("\0", "_"));
        System.out.print(word(START));
        for (String partOfSpeech : model.knownPartsOfSpeech().stream().sorted().collect(Collectors.toList())) {
            System.out.print(word(partOfSpeech));
        }
        System.out.println(word(STOP));
        for (int i = 0; i < phrase.length; i++) {
            String token = phrase[i];
            System.out.print(word(token));
            final int index = i;
            model.knownPartsOfSpeech()
                 .stream()
                 .sorted()
                 .forEach(POS -> {
                     final List<EntryInterface> entries = matrix.getEntries(index);
                     final EntryInterface entry = entries.stream()
                                                 .filter(e -> e.POS().equals(POS))
                                                 .findFirst().orElse(null);
                     if (entry == null) {
                         System.out.print(word("(0,X)"));
                     } else {
                         System.out.print(word(entry));
                     }
                 });
            System.out.print(word("(0,X)"));
            System.out.println();
        }
        System.out.print(word(STOP));
        model.knownPartsOfSpeech()
             .stream()
             .sorted()
             .forEach(partOfSpeech -> {
                 System.out.print(word("(0,X)"));
             });
        System.out.println(matrix.getFinalEntry());
        System.out.println(new String(new char[headline.length()+23]).replaceAll("\0", "_"));
        System.out.println();
    }

    private static String word(Object what) {
        return padRight(String.valueOf(what), 15);
    }

    private static String padRight(String text, int length) {
        return text + new String(new char[Math.max(length - text.length(), 0)]).replaceAll("\0", " ");
    }

    private static VMInterface createVM(final LanguageModelInterface model, final String[] phrase) {
        final VMInterface matrix = new VM();
        for (int i = 0; i < phrase.length; i++) {
            String token = phrase[i];
            final int index = i;
            matrix.addToken(model.knownPartsOfSpeech()
                                 .stream()
                                 .map(POS ->
                                              createEntryForPartOfSpeech(model, matrix, index, token, POS))
                                 .filter(Objects::nonNull)
                                 .collect(Collectors.toList()));
        }
        matrix.setFinalEntry(createFinalEntry(model, phrase, matrix));
        return matrix;
    }

    private static String[] createPhrase() {
        return new String[]{
                "learning",
                "changes",
                "thoroughly"
        };
    }

    private static void Emissions(final LanguageModelInterface model) {
        model.addEmission("learning", VERB, 0.003D);
        model.addEmission("changes", VERB, 0.004D);
        model.addEmission("thoroughly", ADVERB, 0.002D);
        model.addEmission("learning", NOUN, 0.001D);
        model.addEmission("changes", NOUN, 0.003D);
    }

    private static void Transitions(final LanguageModelInterface model) {
        model.addTransition(VERB, START, 0.3D);
        model.addTransition(NOUN, START, 0.2D);
        model.addTransition(VERB, VERB, 0.1D);
        model.addTransition(ADVERB, VERB, 0.4D);
        model.addTransition(NOUN, VERB, 0.4D);
        model.addTransition(NOUN, NOUN, 0.1D);
        model.addTransition(VERB, NOUN, 0.3D);
        model.addTransition(ADVERB, NOUN, 0.1D);
        model.addTransition(STOP, ADVERB, 0.1D);
    }

    private static EntryInterface createFinalEntry(final LanguageModelInterface model, final String[] phrase,
                                          final VMInterface matrix) {
        final List<EntryInterface> entries = matrix.getEntries(phrase.length - 1);
        double max = 0D;
        EntryInterface last = null;
        for (EntryInterface entry : entries) {
            final String POS = entry.POS();
            final double transitionProbability = model.getTransitionProbability(STOP, POS);
            if (transitionProbability == 0) {
                continue;
            }
            double probability = transitionProbability * entry.probability();
            if (probability > max) {
                max = probability;
                last = entry;
            }
        }
        return new Entry(STOP, STOP, last, max);
    }

    private static EntryInterface createEntryForPartOfSpeech(final LanguageModelInterface model, final VMInterface matrix, final int i,
                                                    final String token,
                                                    final String POS) {
        final double emissionProbability = model.getEmissionProbability(token, POS);
        if (emissionProbability == 0D) {
            return null;
        }
        double probability = 0D;
        EntryInterface previous = null;
        if (i > 0) {
            final List<EntryInterface> previousEntries = matrix.getEntries(i - 1);
            for (EntryInterface previousEntry : previousEntries) {
                final double transitionProbability
                        = model.getTransitionProbability(POS, previousEntry.POS());
                if (transitionProbability == 0) {
                    continue;
                }
                double currentProbability =
                        emissionProbability * transitionProbability * previousEntry.probability();
                if (currentProbability > probability) {
                    probability = currentProbability;
                    previous = previousEntry;
                }
            }
        } else {
            final double transitionProbability = model.getTransitionProbability(POS, START);
            if (transitionProbability != 0) {
                probability = transitionProbability * emissionProbability;
            }
        }
        if (probability > 0) {
            return new Entry(POS, token, previous, probability);
        }
        return null;
    }

}


