package hw2;

/**
 * An entry in the language model while calculating the final part of speech tagging for a phrase.
 */
public interface EntryInterface {

    /**
     * @return part of speech for this entry.
     */
    String POS();

    /**
     * @return the token corresponding to this entry.
     */
    String token();

    /**
     * @return the previous entry leading to this entry. {@code null} if this is the first entry
     * in the phrase.
     */
    EntryInterface previous();

    /**
     * @return the probability with which this entry has been reached.
     */
    double probability();

}
