package hw2;

import java.util.Objects;

public class Entry implements EntryInterface {

    private final String POS;
    private final String word;
    private final EntryInterface previous;
    private final double probability;

    public Entry(final String partOfSpeech, final String word,
                        final EntryInterface previous, final double probability) {
        this.POS = partOfSpeech;
        this.word = word;
        this.previous = previous;
        this.probability = probability;
    }

    
    public String POS() {
        return POS;
    }

    
    public String token() {
        return word;
    }

    @Override
    public EntryInterface previous() {
        return previous;
    }

    @Override
    public double probability() {
        return probability;
    }

    @Override
    public String toString() {
        return "(" + probability() + "," + (previous() == null ? Main.START : previous().POS()) + ")";
    }

    @Override
    public boolean equals(final Object o) {
        if (this == o) {
            return true;
        }
        if (o == null || getClass() != o.getClass()) {
            return false;
        }
        final Entry that = (Entry) o;
        return Objects.equals(POS, that.POS) &&
                Objects.equals(word, that.word);
    }

    @Override
    public int hashCode() {
        return Objects.hash(POS, word);
    }

}
